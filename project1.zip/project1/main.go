package main

import (
	"project1/pkg"
)

func main() {
	pkg.TickTockBong()
}
